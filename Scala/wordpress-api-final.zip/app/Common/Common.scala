package common

import play.api._
import javax.inject._
import play.api.libs.ws._
import scala.concurrent._
import play.api.libs.json._
import akka.stream.scaladsl._
import scala.collection.mutable
import scala.util.parsing.json.JSONObject
import scala.concurrent.duration.Duration

class CommonController @Inject()(ws: WSClient) {
  def getWordMap(hostUrl: String): String = { 
    val request: WSRequest = ws.url(hostUrl)
    val res: Future[WSResponse] = request.get()
    // Get Post List
    val posts: List[JsValue] = Json.parse(Await.result(res, Duration.Inf).body).as[List[JsValue]]

    //Combine posts as string
    var combinedPostsContents: String = "";
    for( post <- posts) {
      combinedPostsContents += (post \ "content" \ "rendered").as[String];
    }
    //Remove unnecessary symbols
    combinedPostsContents = combinedPostsContents.replaceAll("""/[^\w\s]/g""", "");
    // Get word frequency
    val counts = mutable.Map.empty[String, Int].withDefaultValue(0)
    for(rawWord <- combinedPostsContents.split(" ")) {
      val word = rawWord.toLowerCase
      counts(word) += 1
    }
    return JSONObject(counts.toMap).toString()
  }
}
