package models

case class HostConnectDto(hosturl: String)
