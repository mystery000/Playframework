package controllers

import play.api._
import play.api.mvc._
import akka.actor._
import javax.inject._
import play.api.libs.ws._
import scala.concurrent._
import play.api.libs.json._
import akka.stream.scaladsl._
import akka.actor.ActorSystem
import models.{HostConnectDto}
import scala.collection.mutable
import play.api.libs.streams.ActorFlow
import scala.util.parsing.json.JSONObject
import scala.concurrent.duration.Duration
import ExecutionContext.Implicits.global
import actors.WebSocketActor
import common.CommonController

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(val controllerComponents: ControllerComponents, ws: WSClient)(implicit actorSystem: ActorSystem) extends BaseController {
  implicit val hostConnectDto = Json.format[HostConnectDto]
  var hostUrl : String = ""

  // endpoint for /api/hostConnect
  def hostConnect() = Action { implicit request => 
    val content = request.body 
    val jsonObject = content.asJson
    //Check if request body is match with dto
    val hostUrlDto: Option[HostConnectDto] = jsonObject.flatMap(Json.fromJson[HostConnectDto](_).asOpt)
    hostUrlDto match {
      case Some(newHostUrl) =>
        hostUrl = (Json.toJson(newHostUrl) \ "hosturl").as[String]
      case None =>
        BadRequest(Json.obj("message" -> "Invalid URL"))
    }
      
    if(hostUrl == "") {
      BadRequest(Json.obj("message" -> "Invalid URL"))
    } else {
      try {
        val request: WSRequest = ws.url(hostUrl)
        val res: Future[WSResponse] = request.get()
        val connectionStatus  = Await.result(res, Duration.Inf).status;
        //URL validator
        if (connectionStatus == 200) { 
          Ok(Json.obj("message" -> "Connection opened. starting service"))
        } else {
          BadRequest(Json.obj("message" -> "Connection failed"))
        }
      } catch {
        case  _: Throwable => BadRequest(Json.obj("message" -> "Invalid URL"))
      }
    }
  }

  def getPosts() = Action { implicit request => 
    try {
      val request: WSRequest = ws.url(hostUrl)
      val res: Future[WSResponse] = request.get()
      val connectionStatus  = Await.result(res, Duration.Inf).status;
      //URL validator
      if (connectionStatus == 200) { 
        val posts: List[JsValue] = Json.parse(Await.result(res, Duration.Inf).body).as[List[JsValue]]
        Ok(Json.stringify(Json.toJson(posts)))
      } else {
        BadRequest(Json.obj("message" -> "Connection failed"))
      }
    } catch {
      case  _: Throwable => BadRequest(Json.obj("message" -> "Invalid URL"))
    }
   
  }

  def socket = WebSocket.accept[String, String] { request =>
    val common: CommonController = new CommonController(ws)
    ActorFlow.actorRef { out =>
      WebSocketActor.props(out, hostUrl, common)
    }
  }
}
