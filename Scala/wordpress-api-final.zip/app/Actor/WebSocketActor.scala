package actors

import akka.actor._
import common.CommonController
import scala.concurrent.duration.Duration

case object SendWordMap

object WebSocketActor {
  def props(out: ActorRef, hostUrl: String, common: CommonController) = Props(new WebSocketActor(out, hostUrl, common))
}

class WebSocketActor(out: ActorRef, hostUrl: String, common: CommonController) extends Actor {
  val tick: Cancellable = {
    context.system.scheduler.schedule(Duration.Zero, Duration(3000, "millis"), self, SendWordMap)(context.system.dispatcher)
  }

  def receive = {
    case SendWordMap =>
      if(hostUrl!="") {
        val wordmap = common.getWordMap(hostUrl)
        out ! (wordmap)
      } else {
        out ! ("")
      }
    case msg: String =>
      if(hostUrl!="") {
        val wordmap = common.getWordMap(hostUrl)
        out ! (wordmap)
      } else {
        out ! ("")
      }
  }
}